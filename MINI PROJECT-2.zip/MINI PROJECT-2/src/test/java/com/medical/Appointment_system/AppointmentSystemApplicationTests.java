package com.medical.Appointment_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
